# TeaWindow 补交包（2026-10-19 24:00 CST 前可替换）

平台：AI4Climate User Center — https://ai4climate.world/account （用报名邮箱免密登录）

内容：
1. 27_一次性提交清单.md  —— 先看这个：字段改什么、两段英文、上传哪些文件、社区帖追加段落
2. TeaWindow_路演.pptx   —— 幻灯片（10 页 + 讲稿备注）
3. 演示视频_自动播放.mp4 —— 介绍视频（56s 纯字幕）
4. 17_最终提交内容.md    —— 三段英文（完整 + 压缩）
5. 24_评审对照表.md      —— 官方 6 维权重 × 证据
6. 25_补交与对接邮件.md  —— 补交/替换 + 90 天 pilot 邮件模板
7. 18_社区帖.md          —— 社区帖（含 10-17 更新）

关键链接：
- Demo: https://teawindow.onrender.com/
- 地块风险图: https://teawindow.onrender.com/terrain.html
- 体检卡: https://teawindow.onrender.com/plot_report.html?lat=30.2215&lon=120.1000
- 社区帖: https://deepseek.club/topic/5179
