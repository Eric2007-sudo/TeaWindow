# TeaWindow 补交包（2026-10-19 前可替换）

1. TeaWindow_路演.pptx        —— 幻灯片（10 页，含逐页讲稿备注，≤30MB）
2. 演示视频_自动播放.mp4      —— 介绍视频（56s，纯字幕，≤200MB）
3. 17_最终提交内容.md         —— 三段英文（完整+压缩）、备用字段
4. 24_评审对照表.md           —— 按官方 6 维权重逐条给证据
5. 25_补交与对接邮件.md       —— 补交/替换 + 90 天 pilot 对接邮件模板
6. 18_社区帖.md               —— 社区帖（含 Markdown 版）

平台字段建议：
- Demo / code repository: https://teawindow.onrender.com/
- DeepSeek.club project post: https://deepseek.club/topic/5179
- Slide deck: TeaWindow_路演.pptx
- Intro video: 演示视频_自动播放.mp4

截止：2026-10-19 24:00（CST）。上传前先访问一次在线 Demo 预热。
