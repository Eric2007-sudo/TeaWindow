# TeaWindow 补交包（2026-10-19 24:00 CST）

平台：https://ai4climate.world/account （报名邮箱免密登录 → View / edit team details）

幻灯片二选一（同版式）：
- TeaWindow_Pitch_EN.pptx   英文精修版（12 页）
- TeaWindow_路演_设计版.pptx 中文设计版（12 页）

视频：演示视频_自动播放.mp4（2:48 / 168s / 21 页纯字幕）
文本：17_最终提交内容.md（三段英文 + 备用字段）
对照：24_评审对照表.md（官方 6 维权重）
邮件：25_补交与对接邮件.md（补交/替换 + 90 天 pilot）
社区帖：18_社区帖.md（含 10-17 更新 + 使用说明）
清单：27_一次性提交清单.md（先看这个）

Demo（可交互网站，不是视频）：https://teawindow.onrender.com/
